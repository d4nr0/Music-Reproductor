let audio;
let isPlaying = false;
let currentVolume = 50;
let isDraggingProgress = false;

function formatTime(seconds) {
  if (isNaN(seconds)) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}

function updateProgress() {
  if (!audio || isNaN(audio.duration) || !isFinite(audio.duration)) return;
  const percent = (audio.currentTime / audio.duration) * 100;
  document.getElementById("progressFill").style.width = `${percent}%`;
  document.getElementById("currentTime").textContent = formatTime(
    audio.currentTime,
  );
}

function setProgress(e) {
  if (!audio || isNaN(audio.duration) || !isFinite(audio.duration)) return;
  const rect = document.getElementById("progressBar").getBoundingClientRect();
  let clientX;
  if (e.type === "click" || e.type === "mousedown" || e.type === "mousemove") {
    clientX = e.clientX;
  } else if (e.type === "keydown") {
    if (e.key === "ArrowLeft") {
      audio.currentTime = Math.max(0, audio.currentTime - 5);
      updateProgress();
    } else if (e.key === "ArrowRight") {
      audio.currentTime = Math.min(audio.duration, audio.currentTime + 5);
      updateProgress();
    }
    return;
  }

  if (!clientX) return;
  let clickX = clientX - rect.left;
  let width = rect.width;
  let percent = Math.min(1, Math.max(0, clickX / width));
  audio.currentTime = percent * audio.duration;
  updateProgress();
}

function initAudio() {
  audio = new Audio();

  audio.src = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3";
  audio.loop = false;
  audio.volume = currentVolume / 100;

  audio.addEventListener("loadedmetadata", () => {
    document.getElementById("duration").textContent = formatTime(
      audio.duration,
    );
  });

  audio.addEventListener("timeupdate", () => {
    if (!isDraggingProgress) {
      updateProgress();
    }
  });

  audio.addEventListener("error", () => {
    document.getElementById("audioStatus").innerHTML =
      "⚠️ Audio sample unavailable";
    document.getElementById("audioStatus").style.color = "#f87171";
  });

  audio.addEventListener("play", () => {
    isPlaying = true;
    updatePlayButton(true);
    document.getElementById("audioStatus").innerHTML = "🎵 Playing";
    document.getElementById("audioStatus").classList.add("playing");
  });

  audio.addEventListener("pause", () => {
    isPlaying = false;
    updatePlayButton(false);
    document.getElementById("audioStatus").innerHTML = "⏸ Paused";
    document.getElementById("audioStatus").classList.remove("playing");
  });

  audio.addEventListener("ended", () => {
    isPlaying = false;
    updatePlayButton(false);
    document.getElementById("audioStatus").innerHTML = "⏹ Finished";
    document.getElementById("audioStatus").classList.remove("playing");
    document.getElementById("progressFill").style.width = "0%";
    document.getElementById("currentTime").textContent = "0:00";
  });

  audio.addEventListener("volumechange", () => {
    const volumePercent = Math.round(audio.volume * 100);
    document.getElementById("volumePercent").textContent = `${volumePercent}%`;
    document.getElementById("volumeSlider").value = volumePercent;
    document
      .getElementById("volumeSlider")
      .setAttribute("aria-valuenow", volumePercent);
    currentVolume = volumePercent;
  });
}

function updatePlayButton(playing) {
  const playIcon = document.getElementById("playIcon");
  if (playing) {
    playIcon.innerHTML =
      '<rect x="6" y="4" width="4" height="16" fill="white"/><rect x="14" y="4" width="4" height="16" fill="white"/>';
  } else {
    playIcon.innerHTML = '<path d="M8 5v14l11-7z" fill="white"/>';
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initAudio();

  const playBtn = document.getElementById("playBtn");
  const volumeSlider = document.getElementById("volumeSlider");
  const muteBtn = document.getElementById("muteBtn");
  const progressBar = document.getElementById("progressBar");

  playBtn.addEventListener("click", () => {
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
    } else {
      audio.play().catch((err) => {
        console.warn("Playback error:", err);
        document.getElementById("audioStatus").innerHTML =
          "⚠️ Click again to play";
      });
    }
  });

  volumeSlider.addEventListener("input", (e) => {
    const val = parseInt(e.target.value, 10);
    currentVolume = val;
    if (audio) {
      audio.volume = val / 100;
    }
    document.getElementById("volumePercent").textContent = `${val}%`;
    e.target.setAttribute("aria-valuenow", val);

    if (audio && audio.muted) {
      audio.muted = false;
      muteBtn.innerHTML = "🔇 Mute";
    }
  });

  muteBtn.addEventListener("click", () => {
    if (!audio) return;
    if (audio.muted) {
      audio.muted = false;
      muteBtn.innerHTML = "🔇 Mute";
      audio.volume = currentVolume / 100;
      volumeSlider.value = currentVolume;
      document.getElementById("volumePercent").textContent =
        `${currentVolume}%`;
    } else {
      audio.muted = true;
      muteBtn.innerHTML = "🔊 Unmute";
      volumeSlider.value = 0;
      document.getElementById("volumePercent").textContent = "0%";
    }
  });

  progressBar.addEventListener("click", setProgress);
  progressBar.addEventListener("mousedown", (e) => {
    isDraggingProgress = true;
    setProgress(e);
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  });

  function onMouseMove(e) {
    if (isDraggingProgress) {
      setProgress(e);
    }
  }

  function onMouseUp() {
    isDraggingProgress = false;
    document.removeEventListener("mousemove", onMouseMove);
    document.removeEventListener("mouseup", onMouseUp);
  }

  progressBar.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
      e.preventDefault();
      setProgress(e);
    }
  });
});
